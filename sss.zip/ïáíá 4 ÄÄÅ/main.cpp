#include <iostream>
#include <vector>
#include <windows.h>

using namespace std;
//Copy і move конструктори + оператор присвоєння доробити!

// Оголошення класу Person
class Person {
public:
    string _name;
    string _surname;

    Person() {}
    Person(string name, string surname) : _name(name), _surname(std::move(surname)) {}
    virtual ~Person() {}

    const string& getName() const { return _name; }
    const string& getSurname() const { return _surname; }


    void setName(const string& name) { _name = name; }
    void setSurname(const string& surname) { _surname = surname; }
};

// Оголошення класу Student
// Оголошення класу Student
class Student : public Person {
public:
    int _groupNumber;
    vector<string> _courses;

    Student() {}
    Student(string name, string surname, int groupNumber, const vector<string>& courses)
            : Person(name, surname), _groupNumber(groupNumber), _courses(courses) {}

    ~Student() {}

    int getGroupNumber() const { return _groupNumber; }
    const vector<string>& getCourses() const { return _courses; }

    void setGroupNumber(int groupNumber) { _groupNumber = groupNumber; }
    void setCourses(const vector<string>& courses) { _courses = courses; }

    // Оператор порівняння для класу Student
    bool operator==(const Student& other) const {
        return (_name == other._name && _surname == other._surname && _groupNumber == other._groupNumber && _courses == other._courses);
    }

    // Конструктор копіювання
    Student(const Student& other) : Person(other), _groupNumber(other._groupNumber), _courses(other._courses) {}

    // Конструктор переміщення
    Student(Student&& other) noexcept : Person(std::move(other)), _groupNumber(std::move(other._groupNumber)), _courses(std::move(other._courses)) {
        // Перемістити дані з іншого об'єкта
        other._groupNumber = 0;
        other._courses.clear();
    }

    // Оператор присвоєння
    Student& operator=(const Student& other) {
        if (this != &other) {
            Person::operator=(other); // Використовуємо базовий оператор присвоєння
            _groupNumber = other._groupNumber;
            _courses = other._courses;
        }
        return *this;
    }
};

// Оголошення класу Group
class Group {
public:
    string _name;
    vector<Student> _students;

    Group() {}
    Group(string name) : _name(name) {}

    const string& getName() const { return _name; }
    const vector<Student>& getStudents() const { return _students; }

    void addStudent(const Student& student) { _students.push_back(student); }

    // Конструктор копіювання
    Group(const Group& other) : _name(other._name), _students(other._students) {}

    // Конструктор переміщення
    Group(Group&& other) noexcept : _name(std::move(other._name)), _students(std::move(other._students)) {
        // Перемістити дані з іншого об'єкта
        other._name = "";
        other._students.clear();
    }

    // Оператор присвоєння
    Group& operator=(const Group& other) {
        if (this != &other) {
            _name = other._name;
            _students = other._students;
        }
        return *this;
    }
};



// Оголошення класу Lecturer
class Lecturer : public Person {
public:
    string _rank;
    vector<string> _disciplines;

    Lecturer() {}
    Lecturer(string name, string surname, string rank, const vector<string>& disciplines)
            : Person(name, surname), _rank(rank), _disciplines(disciplines) {}

    ~Lecturer() {}

    const string& getRank() const { return _rank; }
    const vector<string>& getDisciplines() const { return _disciplines; }

    void setRank(const string& rank) { _rank = rank; }
    void setDisciplines(const vector<string>& disciplines) { _disciplines = disciplines; }

    // Оператор порівняння для класу Lecturer
    bool operator==(const Lecturer& other) const {
        return (_name == other._name && _surname == other._surname && _rank == other._rank && _disciplines == other._disciplines);
    }

    // Конструктор копіювання
    Lecturer(const Lecturer& other) : Person(other), _rank(other._rank), _disciplines(other._disciplines) {}

    // Конструктор переміщення
    Lecturer(Lecturer&& other) noexcept : Person(std::move(other)), _rank(std::move(other._rank)), _disciplines(std::move(other._disciplines)) {
        // Перемістити дані з іншого об'єкта
        other._rank = "";
        other._disciplines.clear();
    }

    // Оператор присвоєння
    Lecturer& operator=(const Lecturer& other) {
        if (this != &other) {
            Person::operator=(other); // Використовуємо базовий оператор присвоєння
            _rank = other._rank;
            _disciplines = other._disciplines;
        }
        return *this;
    }
};

// Оголошення класу University
class University {
public:
    string _name;
    vector<Group> _groups;
    vector<Lecturer> _lecturers;

    University() = default;
    explicit University(string name) : _name(name) {}

    ~University() {}

    const string& getName() const { return _name; }
    const vector<Group>& getGroups() const { return _groups; }
    const vector<Lecturer>& getLecturers() const { return _lecturers; }

    void setName(const string& name) { _name = name; }
    void addGroup(const Group& group) { _groups.push_back(group); }
    void addLecturer(const Lecturer& lecturer) { _lecturers.push_back(lecturer); }

    // Конструктор копіювання
    University(const University& other) : _name(other._name), _groups(other._groups), _lecturers(other._lecturers) {}

    // Конструктор переміщення
    University(University&& other) noexcept : _name(std::move(other._name)), _groups(std::move(other._groups)), _lecturers(std::move(other._lecturers)) {
        // Перемістити дані з іншого об'єкта
        other._name = "";
        other._groups.clear();
        other._lecturers.clear();
    }

    // Оператор присвоєння
    University& operator=(const University& other) {
        if (this != &other) {
            _name = other._name;
            _groups = other._groups;
            _lecturers = other._lecturers;
        }
        return *this;
    }
};

// Клас "Адміністратор"
class Administrator : public Person {
public:
    vector<Student> _students;
    vector<Lecturer> _lecturers;

    Administrator() {}
    Administrator(string name, string surname) : Person(name, surname) {}

    void addStudent(const Student& student) { _students.push_back(student); }
    void removeStudent(const Student& student) {
        for (auto it = _students.begin(); it != _students.end(); ++it) {
            if (*it == student) {
                _students.erase(it);
                break;
            }
        }
    }

    void addLecturer(const Lecturer& lecturer) { _lecturers.push_back(lecturer); }
    void removeLecturer(const Lecturer& lecturer) {
        for (auto it = _lecturers.begin(); it != _lecturers.end(); ++it) {
            if (*it == lecturer) {
                _lecturers.erase(it);
                break;
            }
        }
    }

    // Конструктор копіювання
    Administrator(const Administrator& other) : Person(other), _students(other._students), _lecturers(other._lecturers) {}

    // Конструктор переміщення
    Administrator(Administrator&& other) noexcept : Person(std::move(other)), _students(std::move(other._students)), _lecturers(std::move(other._lecturers)) {
        // Перемістити дані з іншого об'єкта
        other._students.clear();
        other._lecturers.clear();
    }

    // Оператор присвоєння
    Administrator& operator=(const Administrator& other) {
        if (this != &other) {
            Person::operator=(other); // Використовуємо базовий оператор присвоєння
            _students = other._students;
            _lecturers = other._lecturers;
        }
        return *this;
    }
};

class Book {
public:
    string _title;
    string _author;

    Book() {}
    Book(string title, string author) : _title(title), _author(author) {}

    const string& getTitle() const { return _title; }
    const string& getAuthor() const { return _author; }

    // Оператор порівняння для класу Book
    bool operator==(const Book& other) const {
        return (_title == other._title && _author == other._author);
    }
};

// Клас "Бібліотекар"
class Librarian : public Person {
public:
    vector<Book> _books;

    Librarian() {}
    Librarian(string name, string surname) : Person(name, surname) {}

    void addBook(const Book& book) { _books.push_back(book); }
    void removeBook(const Book& book) {
        for (auto it = _books.begin(); it != _books.end(); ++it) {
            if (*it == book) {
                _books.erase(it);
                break;
            }
        }
    }


    Book findBook(const string& title) const {
        for (const Book& book : _books) {
            if (book.getTitle() == title) {
                return book;
            }
        }
        return Book(); // Порожня книга, якщо не знайдено
    }
};

// Клас "Кафедра"
class Department : public University {
public:
    string _name;
    vector<Lecturer> _lecturers;

    Department() {}
    Department(string name, string universityName) : University(universityName), _name(name) {}

    const string& getName() const { return _name; }
    const vector<Lecturer>& getLecturers() const { return _lecturers; }

    void addLecturer(const Lecturer& lecturer) { _lecturers.push_back(lecturer); }
    void removeLecturer(const Lecturer& lecturer) {
        for (auto it = _lecturers.begin(); it != _lecturers.end(); ++it) {
            if (*it == lecturer) {
                _lecturers.erase(it);
                break;
            }
        }
    }
};

// Клас "Предмет"
class Subject : public University {
public:
    string _name;
    vector<Lecturer> _lecturers;

    Subject() {}
    Subject(string name, string universityName) : University(universityName), _name(name) {}

    const string& getName() const { return _name; }
    const vector<Lecturer>& getLecturers() const { return _lecturers; }

    void addLecturer(const Lecturer& lecturer) { _lecturers.push_back(lecturer); }
    void removeLecturer(const Lecturer& lecturer) {
        for (auto it = _lecturers.begin(); it != _lecturers.end(); ++it) {
            if (*it == lecturer) {
                _lecturers.erase(it);
                break;
            }
        }
    }
};

// Приклад використання
int main() {
    SetConsoleOutputCP(CP_UTF8);

    // Створити університет
    University university("Чернівецький національний університет ім. Юрія Федьковича");

    // Створити групи
    Group group1("143 А-1");
    Group group2("143 А-2");

    // Створити студентів
    Student student1("Іван", "Петренко", 1, {"C++", "Java"});
    Student student2("Марія", "Іванова", 2, {"Python", "JavaScript"});

    // Створити викладачів
    Lecturer lecturer1("Петро", "Іванов", "Доцент", {"Програмування", "Алгоритміка"});
    Lecturer lecturer2("Олена", "Петрова", "Старший викладач", {"Математика", "Фізика"});

    // Додати студентів до груп
    group1.addStudent(student1);
    group2.addStudent(student2);

    // Додати групи до університету
    university.addGroup(group1);
    university.addGroup(group2);

    // Створити адміністратора
    Administrator administrator("Анна", "Сидорова");

    // Додати викладачів до списку адміністратора
    administrator.addLecturer(lecturer1);
    administrator.addLecturer(lecturer2);

    // Створити бібліотекаря
    Librarian librarian("Тетяна", "Маркова");

    // Додати книги до бібліотеки
    librarian.addBook(Book("C++: The Complete Reference", "Herbert Schildt"));
    librarian.addBook(Book("Java: The Complete Reference", "Herbert Schildt"));
    librarian.addBook(Book("Python Crash Course", "Eric Matthes"));
    librarian.addBook(Book("JavaScript: The Definitive Guide", "David Flanagan"));

    // Знайти книгу за назвою
    Book book = librarian.findBook("C++: The Complete Reference");
    if (book.getTitle().empty()) {
        cout << "Книга не знайдена" << endl;
    } else {
        cout << "Знайдено книгу: " << book.getTitle() << endl;
    }

    // Створити кафедру
    Department department("Комп'ютерні науки", university.getName());

    // Додати викладачів до кафедри
    department.addLecturer(lecturer1);
    department.addLecturer(lecturer2);

    // Створити предмет
    Subject subject("Програмування", university.getName());

    // Додати викладачів до предмету
    subject.addLecturer(lecturer1);

    // Вивести інформацію про університет
    cout << "Назва університету: " << university.getName() << endl;

    // Вивести інформацію про групи
    for (const Group& group : university.getGroups()) {
        cout << "Назва групи: " << group.getName() << endl;

        // Вивести інформацію про студентів
        for (const Student &student: group.getStudents())
            cout << "  - " << student.getName() << " " << student.getSurname() << endl;

    }

    // Вивести інформацію про адміністратора
    cout << "Адміністратор: " << administrator.getName() << " " << administrator.getSurname() << endl;

    // Вивести інформацію про бібліотекаря
    cout << "Бібліотекар: " << librarian.getName() << " " << librarian.getSurname() << endl;

    // Вивести інформацію про кафедру
    cout << "Назва кафедри: " << department.getName() << endl;

    // Вивести інформацію про предмет
    cout << "Назва предмету: " << subject.getName() << endl;

    return 0;
}