#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <queue>

template<typename T>
class SafeQueue {
private:
    std::queue<T> queue_;
    std::mutex mtx_;
    std::condition_variable cv_;

public:
    void enqueue(const T& item) {
        std::unique_lock<std::mutex> lock(mtx_);
        queue_.push(item);
        cv_.notify_one();
    }

    T dequeue() {
        std::unique_lock<std::mutex> lock(mtx_);
        cv_.wait(lock, [this](){ return !queue_.empty(); });
        T item = queue_.front();
        queue_.pop();
        return item;
    }
};

SafeQueue<int> queue;

void producer() {
    for (int i = 0; i < 10; ++i) {
        queue.enqueue(i);
        std::this_thread::sleep_for(std::chrono::milliseconds(200));
    }
}

void consumer() {
    for (int i = 0; i < 10; ++i) {
        int item = queue.dequeue();
        std::cout << "Consumed: " << item << std::endl;
    }
}

int main() {
    std::thread producer_thread(producer);
    std::thread consumer_thread(consumer);

    producer_thread.join();
    consumer_thread.join();

    return 0;
}