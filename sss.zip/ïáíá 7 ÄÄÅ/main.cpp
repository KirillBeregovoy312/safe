#include <iostream>
#include <memory>
#include <stdexcept>
#include <windows.h>

using namespace std;
template<typename T>
struct Node {
    T data;
    shared_ptr<Node<T>> next;
    shared_ptr<Node<T>> prev; // For doubly linked list
};

template<typename T>
class SinglyLinkedList {
private:
    shared_ptr<Node<T>> head;
    shared_ptr<Node<T>> tail;
    int size;

public:
    SinglyLinkedList() : size(0) {}

    void addFirst(const T& value) {
        auto newNode = make_shared<Node<T>>();
        newNode->data = value;
        newNode->next = head;
        head = newNode;
        if (!tail) tail = newNode;
        size++;
    }

    void addLast(const T& value) {
        auto newNode = make_shared<Node<T>>();
        newNode->data = value;
        newNode->next = nullptr;
        if (!head) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
        size++;
    }

    int getSize() const {
        return size;
    }

    bool isEmpty() const {
        return size == 0;
    }

    shared_ptr<Node<T>> getHead() const {
        return head;
    }
    void removeFirst() {
        if (isEmpty()) {
            throw out_of_range("List is empty");
        }
        head = head->next;
        size--;
    }

    void removeLast() {
        if (isEmpty()) {
            throw out_of_range("List is empty");
        }
        if (size == 1) {
            head = tail = nullptr;
        } else {
            auto currentNode = head;
            while (currentNode->next != tail) {
                currentNode = currentNode->next;
            }
            currentNode->next = nullptr;
            tail = currentNode;
        }
        size--;
    }
};

template<typename T>
class DoublyLinkedList {
private:
    shared_ptr<Node<T>> head;
    shared_ptr<Node<T>> tail;
    int size;

public:
    DoublyLinkedList() : size(0) {}

    void addFirst(const T& value) {
        auto newNode = make_shared<Node<T>>();
        newNode->data = value;
        newNode->next = head;
        if (head) head->prev = newNode;
        head = newNode;
        if (!tail) tail = newNode;
        size++;
    }

    void addLast(const T& value) {
        auto newNode = make_shared<Node<T>>();
        newNode->data = value;
        newNode->next = nullptr;
        if (!head) {
            head = tail = newNode;
        } else {
            newNode->prev = tail;
            tail->next = newNode;
            tail = newNode;
        }
        size++;
    }

    int getSize() const {
        return size;
    }

    bool isEmpty() const {
        return size == 0;
    }

    shared_ptr<Node<T>> getHead() const {
        return head;
    }

    void removeFirst() {
        if (isEmpty()) {
            throw out_of_range("List is empty");
        }
        head = head->next;
        if (head) {
            head->prev = nullptr;
        } else {
            tail = nullptr;
        }
        size--;
    }

    void removeLast() {
        if (isEmpty()) {
            throw out_of_range("List is empty");
        }
        if (size == 1) {
            head = tail = nullptr;
        } else {
            tail = tail->prev;
            tail->next = nullptr;
        }
        size--;
    }
};

int main() {
    SetConsoleOutputCP(CP_UTF8);

    cout << "Однозв'язний список:" << endl;
    SinglyLinkedList<int> sll;
    sll.addFirst(1);
    sll.addLast(2);
    sll.addLast(3);
    sll.addLast(4);

    cout << "Розмір: " << sll.getSize() << endl;
    cout << "Пусто? " << (sll.isEmpty() ? "Так" : "Ні") << endl;

    cout << "Елементи: ";
    auto currentNode = sll.getHead();
    while (currentNode) {
        cout << currentNode->data << " ";
        currentNode = currentNode->next;
    }

    cout << endl;

    sll.removeFirst();
    cout << "Видалення першого елементу в однозв'язному списку: ";
    currentNode = sll.getHead();
    while (currentNode) {
        cout << currentNode->data << " ";
        currentNode = currentNode->next;
    }
    cout << endl;

    sll.removeLast();
    cout << "Видалення останнього елементу в однозв'язному списку: ";
    currentNode = sll.getHead();
    while (currentNode) {
        cout << currentNode->data << " ";
        currentNode = currentNode->next;
    }
    cout << endl;


    cout << "\nДвозв'язний список:" << endl;
    DoublyLinkedList<int> dll;
    dll.addFirst(1);
    dll.addLast(2);
    dll.addLast(3);
    sll.addLast(4);

    cout << "Розмір: " << dll.getSize() << endl;
    cout << "Пусто? " << (dll.isEmpty() ? "Так" : "Ні") << endl;

    cout << "Елементи: ";
    auto currentNode2 = dll.getHead();
    while (currentNode2) {
        cout << currentNode2->data << " ";
        currentNode2 = currentNode2->next;
    }
    cout << endl;

    dll.removeFirst();
    cout << "Видалення першого елементу в двозв'язному списку: ";
    currentNode2 = dll.getHead();
    while (currentNode2) {
        cout << currentNode2->data << " ";
        currentNode2 = currentNode2->next;
    }
    cout << endl;

    dll.removeLast();
    cout << "Видалення останнього елементу в двозв'язному списку: ";
    currentNode2 = dll.getHead();
    while (currentNode2) {
        cout << currentNode2->data << " ";
        currentNode2 = currentNode2->next;
    }
    cout << endl;

    return 0;
}