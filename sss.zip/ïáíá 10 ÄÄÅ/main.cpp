#include <iostream>
#include <stack>
#include <string>
#include <sstream>
#include <cmath>
#include <list>
#include <unordered_map>
#include <algorithm>
#include <vector>
#include <windows.h>

using namespace std;

bool isOperator(char c) {
    return c == '+' || c == '-' || c == '*' || c == '/';
}

int evaluatePostfix(const string& exp) {
    stack<int> operands;
    stringstream ss(exp);
    string token;
    while (ss >> token) {
        if (isdigit(token[0])) {
            operands.push(stoi(token));
        } else if (isOperator(token[0])) {
            int b = operands.top(); operands.pop();
            int a = operands.top(); operands.pop();
            switch (token[0]) {
                case '+': operands.push(a + b); break;
                case '-': operands.push(a - b); break;
                case '*': operands.push(a * b); break;
                case '/': operands.push(a / b); break;
            }
        }
    }
    return operands.top();
}

bool isBalanced(const string& expression) {
    stack<char> s;
    for (char c : expression) {
        if (c == '(' || c == '[' || c == '{') {
            s.push(c);
        } else if (c == ')' || c == ']' || c == '}') {
            if (s.empty()) return false;
            char top = s.top();
            if ((c == ')' && top == '(') || (c == ']' && top == '[') || (c == '}' && top == '{')) {
                s.pop();
            } else {
                return false;
            }
        }
    }
    return s.empty();
}

class LRUCache {
private:
    int capacity;
    list<pair<int, int>> cache;
    unordered_map<int, list<pair<int, int>>::iterator> cacheMap;

public:
    LRUCache(int capacity) : capacity(capacity) {}

    int get(int key) {
        if (cacheMap.find(key) == cacheMap.end()) return -1;
        auto it = cacheMap[key];
        cache.push_front(*it);
        cache.erase(it);
        cacheMap[key] = cache.begin();
        return cacheMap[key]->second;
    }

    void put(int key, int value) {
        if (cacheMap.find(key) != cacheMap.end()) {
            auto it = cacheMap[key];
            cache.erase(it);
        } else if (cache.size() >= capacity) {
            auto del = cache.back();
            cacheMap.erase(del.first);
            cache.pop_back();
        }
        cache.push_front(make_pair(key, value));
        cacheMap[key] = cache.begin();
    }
};

void reverseWords(string& s) {
    reverse(s.begin(), s.end());
    istringstream iss(s);
    string word;
    s = "";
    while (iss >> word) {
        reverse(word.begin(), word.end());
        s += word + " ";
    }
    s.pop_back();
}

double findMedianSortedArrays(vector<int>& nums1, vector<int>& nums2) {
    int m = nums1.size();
    int n = nums2.size();
    int total = m + n;
    int i = 0, j = 0;
    int prev = 0, curr = 0;

    for (int k = 0; k <= total / 2; ++k) {
        prev = curr;
        if (i < m && (j >= n || nums1[i] < nums2[j])) {
            curr = nums1[i++];
        } else {
            curr = nums2[j++];
        }
    }

    if (total % 2 == 0) {
        return (prev + curr) / 2.0;
    } else {
        return curr;
    }
}

int main() {
    SetConsoleOutputCP(CP_UTF8);
    // 1. Обчисліть постфіксний вираз
    string exp = "3 4 2 * +";
    cout << "Результат обчислення постфіксного виразу: " << evaluatePostfix(exp) << endl;

    // 2. Перевірте збалансовані дужки
    string expression = "{[()]}";
    if (isBalanced(expression)) {
        cout << "Дужки збалансовані" << endl;
    } else {
        cout << "Дужки не збалансовані" << endl;
    }

    // 3. Моделювання роботи кешу
    LRUCache cache(2);
    cache.put(1, 1); //1, 1
    cache.put(2, 2); //2, 2
    cout << "Значення для ключа 1: " << cache.get(1) << endl; //1
    cache.put(3, 3); //3, 3
    cout << "Значення для ключа 2: " << cache.get(2) << endl; //2
    cache.put(4, 4); //4, 4
    cout << "Значення для ключа 1: " << cache.get(1) << endl;
    cout << "Значення для ключа 3: " << cache.get(3) << endl;
    cout << "Значення для ключа 4: " << cache.get(4) << endl;

    // 4. Зворотне речення
    string sentence = "Привіт світ!";
    reverseWords(sentence);
    cout << "Зворотне речення: " << sentence << endl;

    // 5. Медіана двох відсортованих масивів
    vector<int> nums1 = {1, 3};
    vector<int> nums2 = {2};
    cout << "Медіана двох відсортованих масивів " << findMedianSortedArrays(nums1, nums2) << endl;

    return 0;
}