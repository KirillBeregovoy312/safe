#include <iostream>
#include <vector>
#include <windows.h>
using namespace std;

class Student {
public:
    // Модифікатори доступу
    // Ім'я
    string _name;
    // Прізвище
    string _surname;
    // Номер групи
    int _groupNumber;

    // Конструктор за замовчуванням
    Student() {

    }

    // Перевантажений конструктор
    Student(string name, string surname, int groupNumber)
            : _name(name), _surname(surname), _groupNumber(groupNumber) {}

    // Деструктор
    ~Student() {
        cout << "Деструктор викликався студент" << endl;
    }

    // Геттери
    const string& getName() const { return _name; }
    const string& getSurname() const { return _surname; }
    int getGroupNumber() const { return _groupNumber; }

    // Сеттери
    void setName(const string& name) { _name = name; }
    void setSurname(const string& surname) { _surname = surname; }
    void setGroupNumber(int groupNumber) { _groupNumber = groupNumber; }


};

class Group {
public:
    // Модифікатори доступу
    // Назва групи
    string _name;
    int m;
    // Список студентів
    vector<Student> _students;

    // Конструктор за замовчуванням
    Group() {}

    // Перевантажений конструктор
    Group(string name) : Group(name, 5) {}
    Group(string name, int n) : _name{name}, m{n} {}

    // Деструктор
    ~Group() {
        cout << "Деструктор викликався група" << endl;
    }

    // Геттери
    const string& getName() const { return _name; }
    const vector<Student>& getStudents() const { return _students; }

    // Сеттери
    void setName(const string& name) { _name = name; }

    // Додати студента
    void addStudent(const Student& student) { _students.push_back(student); }


};

class University {
public:
    // Модифікатори доступу
    // Назва університету
    string _name;
    // Список груп
    vector<Group> _groups;

    // Конструктор за замовчуванням
    University() {}

    // Перевантажений конструктор
    University(string name) : _name(name) {}

    // Деструктор
    ~University() {
        cout << "Деструктор викликався університет" << endl;
    }

    // Геттери
    const string& getName() const { return _name; }
    const vector<Group>& getGroups() const { return _groups; }

    // Сеттери
    void setName(const string& name) { _name = name; }

    // Додати групу
    void addGroup(const Group& group) { _groups.push_back(group); }


};

int main() {
    SetConsoleOutputCP(CP_UTF8);
    // Створити університет
    University university("Чернівецький національний університет ім. Юрія Федьковича");

    // Створити групи
    Group group1("143 А-1");
    Group group2("143 А-2");

    // Створити студентів
    Student student1("Іван", "Петренко", 1);
    Student student2("Марія", "Іванова", 2);

    // Додати студентів до груп
    group1.addStudent(student1);
    group2.addStudent(student2);

    // Додати групи до університету
    university.addGroup(group1);
    university.addGroup(group2);

    // Вивести інформацію про університет
    cout << "Назва університету: " << university.getName() << endl;

    // Вивести інформацію про групи
    for (const Group& group : university.getGroups()) {
        cout << "Назва групи: " << group.getName() << endl;

        // Вивести інформацію про студентів
        for (const Student& student : group.getStudents()) {
            cout << "  - " << student.getName() << " " << student.getSurname() << endl;
        }
    }

    return 0;
}