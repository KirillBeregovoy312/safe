#include <iostream>
#include <vector>
#include <deque>
#include <array>
#include <windows.h>

template <typename T, std::size_t N1, std::size_t N2>
std::array<T, N1 + N2> mergeArrays(const std::array<T, N1>& arr1, const std::array<T, N2>& arr2) {
    std::array<T, N1 + N2> mergedArr;

    // Об'єднати відсортовані масиви
    std::size_t i = 0, j = 0, k = 0;
    while (i < N1 && j < N2) {
        if (arr1[i] <= arr2[j]) {
            mergedArr[k++] = arr1[i++];
        } else {
            mergedArr[k++] = arr2[j++];
        }
    }

    // Копіювати решту елементів arr1
    while (i < N1) {
        mergedArr[k++] = arr1[i++];
    }

    // Копіювати решту елементів arr2
    while (j < N2) {
        mergedArr[k++] = arr2[j++];
    }

    return mergedArr;
}

template <typename T>
void printContainer(const T& container) {
    for (const auto& item : container) {
        std::cout << item << " ";
    }
    std::cout << std::endl;
}

template <typename T>
void partitionVector(std::vector<T>& vec) {
    std::vector<T> evens;
    std::vector<T> odds;

    for (const auto& item : vec) {
        if (item % 2 == 0) {
            evens.push_back(item);
        } else {
            odds.push_back(item);
        }
    }

    vec.clear(); // Очистити вихідний вектор

    // Перенести парні числа на початок вектора
    vec.insert(vec.end(), evens.begin(), evens.end());

    // Додавання непарних чисел до кінця вектора
    vec.insert(vec.end(), odds.begin(), odds.end());
}

template <typename T>
bool isPalindrome(const std::deque<T>& deque) {
    std::deque<T> reversedDeque(deque.rbegin(), deque.rend());
    return std::equal(deque.begin(), deque.end(), reversedDeque.begin());
}

int main() {
    SetConsoleOutputCP(CP_UTF8);
    // 1. Об'єднати масиви
    std::array<int, 5> arr1 = {1, 3, 5, 7, 9};
    std::array<int, 4> arr2 = {2, 4, 6, 8};

    auto mergedArr = mergeArrays(arr1, arr2);
    std::cout << "Об'єднаний масив: ";
    printContainer(mergedArr);

    // 2. Вектор розбиття
    std::vector<int> vec = {1, 2, 3, 4, 5, 6, 7, 8, 9};

    partitionVector(vec);
    std::cout << "Парні числа: ";
    printContainer(vec);

    std::cout << "Непарні числа: ";
    // Надрукувати другу половину вектора (непарні числа)
    for (size_t i = vec.size() / 2; i < vec.size(); ++i) {
        std::cout << vec[i] << " ";
    }
    std::cout << std::endl;

    // 3. Перевірте паліндром
    std::deque<char> deque = {'a', 'b', 'c', 'c', 'b', 'a'}; //b

    if (isPalindrome(deque)) {
        std::cout << "Deque є паліндром" << std::endl;
    } else {
        std::cout << "Deque не є паліндром" << std::endl;
    }

    return 0;
}