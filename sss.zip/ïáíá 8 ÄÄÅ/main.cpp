#include <iostream>
#include <memory>
#include <stdexcept>
#include <vector>
#include <windows.h>

using namespace std;
template<typename T>
struct Node {
    T data;
    shared_ptr<Node<T>> next;
    shared_ptr<Node<T>> prev;
};

template<typename T>
class SinglyLinkedList {
private:
    shared_ptr<Node<T>> head;
    shared_ptr<Node<T>> tail;
    int size;

public:
    SinglyLinkedList() : size(0) {}

    void addFirst(const T& value) {
        auto newNode = make_shared<Node<T>>();
        newNode->data = value;
        newNode->next = head;
        head = newNode;
        if (!tail) tail = newNode;
        size++;
    }

    void addLast(const T& value) {
        auto newNode = make_shared<Node<T>>();
        newNode->data = value;
        newNode->next = nullptr;
        if (!head) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
        size++;
    }



    int getSize() const {
        return size;
    }

    bool isEmpty() const {
        return size == 0;
    }

    shared_ptr<Node<T>> getHead() const {
        return head;
    }


};

template<typename T>
class DoublyLinkedList {
private:
    shared_ptr<Node<T>> head;
    shared_ptr<Node<T>> tail;
    int size;

public:
    DoublyLinkedList() : size(0) {}

    void addFirst(const T& value) {
        auto newNode = make_shared<Node<T>>();
        newNode->data = value;
        newNode->next = head;
        if (head) head->prev = newNode;
        head = newNode;
        if (!tail) tail = newNode;
        size++;
    }

    void addLast(const T& value) {
        auto newNode = make_shared<Node<T>>();
        newNode->data = value;
        newNode->next = nullptr;
        if (!head) {
            head = tail = newNode;
        } else {
            newNode->prev = tail;
            tail->next = newNode;
            tail = newNode;
        }
        size++;
    }

    int getSize() const {
        return size;
    }

    bool isEmpty() const {
        return size == 0;
    }

    shared_ptr<Node<T>> getHead() const {
        return head;
    }


};

// Реалізація класу черги
template<typename T>
class Queue {
private:
    shared_ptr<Node<T>> head;
    shared_ptr<Node<T>> tail;
    int size;

public:
    Queue() : size(0) {}

    void enqueue(const T& value) {
        auto newNode = make_shared<Node<T>>();
        newNode->data = value;
        newNode->next = nullptr;

        if (!head) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
        size++;
    }

    T dequeue() {
        if (isEmpty()) {
            throw runtime_error("Queue is empty");
        }

        auto temp = head;
        head = head->next;
        size--;

        if (!head) {
            tail = nullptr;
        }

        return temp->data;
    }

    T peek() const {
        if (isEmpty()) {
            throw runtime_error("Queue is empty");
        }

        return head->data;
    }

    int getSize() const {
        return size;
    }

    bool isEmpty() const {
        return size == 0;
    }
};
// Реалізація класу PriorityQueue
template<typename T, typename Comparator>
class PriorityQueue {
private:
    std::vector<T> data;
    Comparator compare;

    void heapifyUp(int index) {
        while (index > 0) {
            int parentIndex = (index - 1) / 2;
            if (compare(data[parentIndex], data[index])) {
                std::swap(data[parentIndex], data[index]);
                index = parentIndex;
            } else {
                break;
            }
        }
    }

    void heapifyDown(int index) {
        int leftChildIndex = 2 * index + 1;
        int rightChildIndex = 2 * index + 2;

        int largestIndex = index;
        if (leftChildIndex < data.size() && compare(data[largestIndex], data[leftChildIndex])) {
            largestIndex = leftChildIndex;
        }

        if (rightChildIndex < data.size() && compare(data[largestIndex], data[rightChildIndex])) {
            largestIndex = rightChildIndex;
        }

        if (largestIndex != index) {
            std::swap(data[largestIndex], data[index]);
            heapifyDown(largestIndex);
        }
    }

public:
    PriorityQueue(Comparator compareFunc) : compare(compareFunc) {}

    void enqueue(const T& value) {
        data.push_back(value);
        heapifyUp(data.size() - 1);
    }

    T dequeue() {
        if (isEmpty()) {
            throw std::runtime_error("Priority queue is empty");
        }

        T top = data[0];
        data[0] = data.back();
        data.pop_back();
        heapifyDown(0);

        return top;
    }

    T peek() const {
        if (isEmpty()) {
            throw std::runtime_error("Priority queue is empty");
        }

        return data[0];
    }

    int getSize() const {
        return data.size();
    }

    bool isEmpty() const {
        return data.empty();
    }
};

// Реалізація класу стека
template<typename T>
class Stack {
private:
    std::shared_ptr<Node<T>> top;
    int size;

public:
    Stack() : size(0) {}

    void push(const T& value) {
        auto newNode = std::make_shared<Node<T>>();
        newNode->data = value;
        newNode->next = top;
        top = newNode;
        size++;
    }

    T pop() {
        if (isEmpty()) {
            throw std::runtime_error("Stack is empty");
        }

        auto temp = top;
        top = top->next;
        size--;

        return temp->data;
    }

    T peek() const {
        if (isEmpty()) {
            throw std::runtime_error("Stack is empty");
        }

        return top->data;
    }

    int getSize() const {
        return size;
    }

    bool isEmpty() const {
        return size == 0;
    }
};
// Реалізація черги на основі масиву
template<typename T, size_t N>
class ArrayQueue {
private:
    T data[N];
    int head;
    int tail;
    int size;

public:
    ArrayQueue() : head(0), tail(0), size(0) {}

    void enqueue(const T& value) {
        if (isFull()) {
            throw std::runtime_error("Queue is full");
        }

        data[tail] = value;
        tail = (tail + 1) % N;
        size++;
    }

    T dequeue() {
        if (isEmpty()) {
            throw std::runtime_error("Queue is empty");
        }

        T front = data[head];
        head = (head + 1) % N;
        size--;

        return front;
    }

    T peek() const {
        if (isEmpty()) {
            throw std::runtime_error("Queue is empty");
        }

        return data[head];
    }

    int getSize() const {
        return size;
    }

    bool isEmpty() const {
        return size == 0;
    }

    bool isFull() const {
        return size == N;
    }
};

// Реалізація стеку на основі масиву
template<typename T, size_t N>
class ArrayStack {
private:
    T data[N];
    int top;

public:
    ArrayStack() : top(0) {}

    void push(const T& value) {
        if (isFull()) {
            throw std::runtime_error("Stack is full");
        }

        data[top++] = value;
    }

    T pop() {
        if (isEmpty()) {
            throw std::runtime_error("Stack is empty");
        }

        return data[--top];
    }

    T peek() const {
        if (isEmpty()) {
            throw std::runtime_error("Stack is empty");
        }

        return data[top - 1];
    }

    int getSize() const {
        return top;
    }

    bool isEmpty() const {
        return top == 0;
    }

    bool isFull() const {
        return top == N;
    }
};


int main() {
    SetConsoleOutputCP(CP_UTF8);

    std::cout << "Однозв'язаний список:" << std::endl;
    SinglyLinkedList<int> sll;
    sll.addFirst(1);
    sll.addLast(2);
    sll.addLast(3);
    sll.addLast(4);

    std::cout << "Розмір: " << sll.getSize() << std::endl;
    std::cout << "Пусто? " << (sll.isEmpty() ? "Так" : "Ні") << std::endl;

    std::cout << "Елементи: ";
    auto currentNode = sll.getHead();
    while (currentNode) {
        std::cout << currentNode->data << " ";
        currentNode = currentNode->next;
    }
    std::cout << std::endl;


    std::cout << "\nДвозв'язаний список:" << std::endl;
    DoublyLinkedList<int> dll;
    dll.addFirst(1);
    dll.addLast(2);
    dll.addLast(3);

    std::cout << "Розмір: " << dll.getSize() << std::endl;
    std::cout << "Пусто? " << (dll.isEmpty() ? "Так" : "Ні") << std::endl;

    std::cout << "Елементи: ";
    auto currentNode2 = dll.getHead();
    while (currentNode2) {
        std::cout << currentNode2->data << " ";
        currentNode2 = currentNode2->next;
    }
    std::cout << std::endl;

    std::cout << "\nЧерга на основі масиву:" << std::endl;
    ArrayQueue<int, 10> aq;
    aq.enqueue(1);
    aq.enqueue(2);
    aq.enqueue(3);
    aq.enqueue(4);

    std::cout << "Розмір: " << aq.getSize() << std::endl;
    std::cout << "Пусто? " << (aq.isEmpty() ? "Так" : "Ні") << std::endl;

    std::cout << "Елементи: ";
    while (!aq.isEmpty()) {
        std::cout << aq.dequeue() << " ";
    }
    std::cout << std::endl;


    std::cout << "\nПріоритетна черга на основі динамічної пам’яті:" << std::endl;
    auto compareFunc = [](int a, int b) { return a > b; };
    PriorityQueue<int, decltype(compareFunc)> pq(compareFunc);
    pq.enqueue(10);
    pq.enqueue(5);
    pq.enqueue(20);
    pq.enqueue(3);

    std::cout << "Розмір: " << pq.getSize() << std::endl;
    std::cout << "Пусто? " << (pq.isEmpty() ? "Так" : "Ні") << std::endl;

    std::cout << "Елементи: ";
    while (!pq.isEmpty()) {
        std::cout << pq.dequeue() << " ";
    }
    std::cout << std::endl;


    std::cout << "\nСтек на основі масиву:" << std::endl;
    ArrayStack<int, 10> as;
    as.push(1);
    as.push(2);
    as.push(3);
    as.push(4);

    std::cout << "Розмір: " << as.getSize() << std::endl;
    std::cout << "Пусто? " << (as.isEmpty() ? "Так" : "Ні") << std::endl;

    std::cout << "Елементи: ";
    while (!as.isEmpty()) {
        std::cout << as.pop() << " ";
    }
    std::cout << std::endl;


    std::cout << "\nЧерга пов’язаного списку:" << std::endl;
    Queue<int> llq;
    llq.enqueue(1);
    llq.enqueue(2);
    llq.enqueue(3);
    llq.enqueue(4);

    std::cout << "Розмір: " << llq.getSize() << std::endl;
    std::cout << "Пусто? " << (llq.isEmpty() ? "Так" : "Ні") << std::endl;

    std::cout << "Елементи: ";
    while (!llq.isEmpty()) {
        std::cout << llq.dequeue() << " ";
    }
    std::cout << std::endl;


    std::cout << "\nПов’язаний стек списків:" << std::endl;
    Stack<int> lls;
    lls.push(1);
    lls.push(2);
    lls.push(3);
    lls.push(4);

    std::cout << "Розмір: " << lls.getSize() << std::endl;
    std::cout << "Пусто? " << (lls.isEmpty() ? "Так" : "Ні") << std::endl;

    std::cout << "Елементи: ";
    while (!lls.isEmpty()) {
        std::cout << lls.pop() << " ";
    }
    std::cout << std::endl;

    return 0;
}