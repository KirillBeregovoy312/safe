#include <iostream>
#include <thread>
#include <mutex>

using namespace std;
int counter = 0;
mutex mtx;

void increase_counter(int thread_id) {
    for (int i = 0; i < 5; ++i) {
        mtx.lock();
        counter += thread_id;
        cout << "Counter value: " << counter << endl;
        mtx.unlock();
    }
}

int main() {
    thread t1(increase_counter, 1);
    thread t2(increase_counter, 2);

    t1.join();
    t2.join();

    return 0;
}