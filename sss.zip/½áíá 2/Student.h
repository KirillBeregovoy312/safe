//
// Created by User on 26.02.2024.
//

/*#ifndef _2_STUDENT_H
#define _2_STUDENT_H
#include <iostream>
#include <vector>
#include <windows.h>

using namespace std;
class Student {
public:
    // Модифікатори доступу
    // Ім'я
    string _name;
    // Прізвище
    string _surname;
    // Номер групи
    int _groupNumber;

    // Конструктор за замовчуванням
    Student() {}

    // Перевантажений конструктор
    Student(string name, string surname, int groupNumber)
            : _name(name), _surname(surname), _groupNumber(groupNumber) {}

    // Деструктор
    ~Student() {
        cout << "Деструктор викликався для студента " << _name << " " << _surname << endl;
    }

    // Геттери
    const string& getName() const { return _name; }
    const string& getSurname() const { return _surname; }
    int getGroupNumber() const { return _groupNumber; }

    // Сеттери
    void setName(const string& name) { _name = name; }
    void setSurname(const string& surname) { _surname = surname; }
    void setGroupNumber(int groupNumber) { _groupNumber = groupNumber; }

    // Конструктор копіювання
    Student(const Student& other) {
        _name = other._name;
        _surname = other._surname;
        _groupNumber = other._groupNumber;
    }

    // Конструктор переміщення
    Student(Student&& other) noexcept {
        _name = std::move(other._name);
        _surname = std::move(other._surname);
        _groupNumber = std::move(other._groupNumber);

        // Очистити дані з 'other', щоб уникнути подвійного звільнення
        other._name = "";
        other._surname = "";
        other._groupNumber = 0;
    }

    void printInfo() {
        cout << "Ім'я: " << this->_name << endl;
        cout << "Прізвище: " << this->_surname << endl;
        cout << "Номер групи: " << this->_groupNumber << endl;
    }

    // Унарний оператор +
    Student operator+() const {
        Student copy = *this;
        copy._name += " (копія)";
        return copy;
    }
};


#endif //_2_STUDENT_H
*/