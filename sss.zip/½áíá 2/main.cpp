#include <iostream>
#include <vector>
#include <windows.h>
using namespace std;

class Student {
public:
    // Модифікатори доступу
    // Ім'я
    string _name;
    // Прізвище
    string _surname;
    // Номер групи
    int _groupNumber;

    // Конструктор за замовчуванням
    Student() {}

    // Перевантажений конструктор
    Student(string name, string surname, int groupNumber)
            : _name(name), _surname(surname), _groupNumber(groupNumber) {}

    // Деструктор
    ~Student() {
        cout << "Деструктор викликався для студента " << _name << " " << _surname << endl;
    }

    // Геттери
    const string& getName() const { return _name; }
    const string& getSurname() const { return _surname; }
    int getGroupNumber() const { return _groupNumber; }

    // Сеттери
    void setName(const string& name) { _name = name; }
    void setSurname(const string& surname) { _surname = surname; }
    void setGroupNumber(int groupNumber) { _groupNumber = groupNumber; }

    // Конструктор копіювання
    Student(const Student& other) {
        _name = other._name;
        _surname = other._surname;
        _groupNumber = other._groupNumber;
    }

    // Конструктор переміщення
    Student(Student&& other) noexcept {
        _name = std::move(other._name);
        _surname = std::move(other._surname);
        _groupNumber = std::move(other._groupNumber);

        // Очистити дані з 'other', щоб уникнути подвійного звільнення
        other._name = "";
        other._surname = "";
        other._groupNumber = 0;
    }

    void printInfo() {
        cout << "Ім'я: " << this->_name << endl;
        cout << "Прізвище: " << this->_surname << endl;
        cout << "Номер групи: " << this->_groupNumber << endl;
    }

    // Унарний оператор +
    Student operator+() const {
        Student copy = *this;
        copy._name += " (копія)";
        return copy;
    }
    friend istream& operator>>(istream &in, Student &student) {
        cout << "Введіть ім'я: ";
        in >> student._name;

        cout << "Введіть прізвище: ";
        in >> student._surname;

        cout << "Введіть номер групи: ";
        int groupNumber;
        in >> groupNumber;

        // Перевірка валідності номера групи
        while (groupNumber <= 0) {
            cout << "Невірний номер групи. Введіть ще раз: ";
            in >> groupNumber;
        }

        student._groupNumber = groupNumber;

        return in;
    }

// Перевантаження оператора <<
    friend ostream& operator<<(ostream& out, const Student& student) {
        out << "Ім'я: " << student._name << endl;
        out << "Прізвище: " << student._surname << endl;
        out << "Номер групи: " << student._groupNumber << endl;

        return out;
    }

// Бінарний оператор +
    Student operator+(const Student& lhs) {
        Student result;
        result._name = lhs._name + " " + this->_name;
        result._surname = lhs._surname + " " + this->_surname;
        // Додавання номерів груп не має сенсу
        // result._groupNumber = lhs._groupNumber + rhs._groupNumber;

        return result;
    }
};

class Group {
public:
    // Модифікатори доступу
    // Назва групи
    string _name;
    // Список студентів
    vector<Student> _students;

    // Конструктор за замовчуванням
    Group() {}

    // Перевантажений конструктор
    Group(string name) : _name(name) {}

    // Деструктор
    ~Group() {
        cout << "Деструктор викликався для групи " << _name << endl;
    }

    // Геттери
    const string& getName() const { return _name; }
        // Сеттери
        void setName(const string& name) { _name = name; }

        // Додати студента
        void addStudent(Student&& student) {
            _students.push_back(std::move(student));
        }

        // Отримати ітератор на початок списку
        vector<Student>::iterator begin() { return _students.begin(); }

        // Отримати ітератор на кінець списку
        vector<Student>::iterator end() { return _students.end(); }
    };

    class University {
    public:
        // Модифікатори доступу
        // Назва університету
        string _name;
        // Список груп
        vector<Group> _groups;

        // Конструктор за замовчуванням
        University() {}

        // Перевантажений конструктор
        University(string name) : _name(name) {}

        // Деструктор
        ~University() {
            cout << "Деструктор викликався для університету " << _name << endl;
            for (Group& group : _groups) {
                group.~Group();
            }
        }

        // Геттери
        const string& getName() const { return _name; }
        const vector<Group>& getGroups() const { return _groups; }

        // Сеттери
        void setName(const string& name) { _name = name; }

        // Додати групу
        void addGroup(Group&& group) {
            _groups.push_back(std::move(group));
        }

        static int _numberOfUniversities;

        explicit University(University&& u) : _name(std::move(u._name)) {
            _numberOfUniversities++;
        }

        static int getNumberOfUniversities() {
            return _numberOfUniversities;
        }

    };

// Перевантаження оператора >>


    int University::_numberOfUniversities = 0;
void printStudentInfo(const Student& student) {
    cout << student.getName() << " " << student.getSurname() << " (" << student.getGroupNumber() << ")" << endl;
}
    int main() {
        SetConsoleOutputCP(CP_UTF8);

        // Створити університет
        University university("Чернівецький національний університет ім. Юрія Федьковича");

        // Створити групи
        Group group1("143 А-1");
        Group group2("143 А-2");

        // Створити студентів
        Student student1("Іван", "Петренко", 1);
        Student student2("Марія", "Іванова", 2);

        // Додати студентів до груп
        group1.addStudent(move(student1));
        group2.addStudent(move(student2));

        // Додати групи до університету
        university.addGroup(move(group1));
        university.addGroup(move(group2));

        // Вивести інформацію про університет
        cout << "Назва університету: " << university.getName() << endl;

        // Вивести інформацію про групи
        for (const Group& group : university.getGroups()) {
            cout << "Назва групи: " << group.getName() << endl;

            // Вивести інформацію про студентів
            for (const Student& student : group._students) {
                cout << "  - ";
                // Демонстрація const
                printStudentInfo(student);
            }
        }

        // Демонстрація унарного оператора +
        Student student3 = student1 + student2;
        cout << "Інформація про студента 3: " << endl;
        student3.printInfo();

        // Демонстрація бінарного оператора +
        Student student4 = student1 + student2;
        cout << "Інформація про студента 4: " << endl;
        student4.printInfo();

        // Демонстрація введення даних
        Student student5;
        cin >> student5;
        cout << "Інформація про студента 5: " << endl;
        cout << student5;

        return 0;
    }


