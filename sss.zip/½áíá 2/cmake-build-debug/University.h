//
// Created by User on 10.03.2024.
//

/*#ifndef _2_UNIVERSITY_H
#define _2_UNIVERSITY_H
#include <iostream>
#include <vector>
#include <windows.h>

using namespace std;
class University {
public:
    // Модифікатори доступу
    // Назва університету
    string _name;
    // Список груп
    vector<Group> _groups;

    // Конструктор за замовчуванням
    University() {}

    // Перевантажений конструктор
    University(string name) : _name(name) {}

    // Деструктор
    ~University() {
        cout << "Деструктор викликався для університету " << _name << endl;
        for (Group& group : _groups) {
            group.~Group();
        }
    }

    // Геттери
    const string& getName() const { return _name; }
    const vector<Group>& getGroups() const { return _groups; }

    // Сеттери
    void setName(const string& name) { _name = name; }

    // Додати групу
    void addGroup(Group&& group) {
        _groups.push_back(std::move(group));
    }

    static int _numberOfUniversities;

    University(string name) : _name(std::move(name)) {
        _numberOfUniversities++;
    }

    static int getNumberOfUniversities() {
        return _numberOfUniversities;
    }
};

// Перевантаження оператора >>
friend istream& operator>>(istream& in, Student& student);

istream &operator>>(istream &in, Student &student) {
    cout << "Введіть ім'я: ";
    in >> student._name;

    cout << "Введіть прізвище: ";
    in >> student._surname;

    cout << "Введіть номер групи: ";
    int groupNumber;
    in >> groupNumber;

    // Перевірка валідності номера групи
    while (groupNumber <= 0) {
        cout << "Невірний номер групи. Введіть ще раз: ";
        in >> groupNumber;
    }

    student._groupNumber = groupNumber;

    return in;
}

// Перевантаження оператора <<
friend ostream& operator<<(ostream& out, const Student& student) {
    out << "Ім'я: " << student._name << endl;
    out << "Прізвище: " << student._surname << endl;
    out << "Номер групи: " << student._groupNumber << endl;

    return out;
}

// Бінарний оператор +
friend Student operator+(const Student& lhs, const Student& rhs) {
    Student result;
    result._name = lhs._name + " " + rhs._name;
    result._surname = lhs._surname + " " + rhs._surname;
    // Додавання номерів груп не має сенсу
    // result._groupNumber = lhs._groupNumber + rhs._groupNumber;

    return result;

};


#endif //_2_UNIVERSITY_H
*/