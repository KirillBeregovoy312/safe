//
// Created by User on 10.03.2024.
//

/*#ifndef _2_GROUP_H
#define _2_GROUP_H
#include <iostream>
#include <vector>
#include <windows.h>

using namespace std;
class Group {
public:
    // Модифікатори доступу
    // Назва групи
    string _name;
    // Список студентів
    vector<Student> _students;

    // Конструктор за замовчуванням
    Group() {}

    // Перевантажений конструктор
    Group(string name) : _name(name) {}

    // Деструктор
    ~Group() {
        cout << "Деструктор викликався для групи " << _name << endl;
    }

    // Геттери
    const string& getName() const { return _name; }
    // Сеттери
    void setName(const string& name) { _name = name; }

    // Додати студента
    void addStudent(Student&& student) {
        _students.push_back(std::move(student));
    }

    // Отримати ітератор на початок списку
    vector<Student>::iterator begin() const { return _students.begin(); }

    // Отримати ітератор на кінець списку
    vector<Student>::iterator end() { return _students.end(); }
};


#endif //_2_GROUP_H
*/