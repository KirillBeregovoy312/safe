#include <iostream>
#include <thread>

using namespace std;

int counter = 0;

void increase_counter(int thread_id) {
    for (int i = 0; i < 5; ++i) {
        counter += thread_id;
        cout << "\nCounter value: " << counter << endl;
    }
}

int main() {
    thread t1(increase_counter, 1);
    thread t2(increase_counter, 2);

    t1.join();
    t2.join();

    return 0;
}