#include <iostream>
#include <vector>
#include <string>
#include <memory>

using namespace std;

// Абстрактний клас - інтерфейс
class Student {
public:
    virtual void displayInfo() const = 0; // Чисто віртуальна функція

    // Віртуальний деструктор
    virtual ~Student() {}

    // Віртуальні функції
    virtual void study() const {
        cout << "Student is studying..." << endl;
    }

    virtual void sleep() const {
        cout << "Student is sleeping..." << endl;
    }
};

// Клас, що реалізує інтерфейс Student
class Undergraduate : public Student {
private:
    string name;
    string surname;
    int groupNumber;

public:
    // Конструктор
    Undergraduate(string n, string s, int g) : name(n), surname(s), groupNumber(g) {}

    // Перевизначення чисто віртуальної функції
    void displayInfo() const override {
        cout << "Undergraduate Student Info:" << endl;
        cout << "Name: " << name << endl;
        cout << "Surname: " << surname << endl;
        cout << "Group Number: " << groupNumber << endl;
    }
};

// Клас, що також реалізує інтерфейс Student
class Postgraduate : public Student {
private:
    string name;
    string surname;
    int groupNumber;

public:
    // Конструктор
    Postgraduate(string n, string s, int g) : name(n), surname(s), groupNumber(g) {}

    // Перевизначення чисто віртуальної функції
    void displayInfo() const override {
        cout << "Postgraduate Student Info:" << endl;
        cout << "Name: " << name << endl;
        cout << "Surname: " << surname << endl;
        cout << "Group Number: " << groupNumber << endl;
    }

    // Перевизначення віртуальної функції
    void study() const override {
        cout << "Postgraduate is researching..." << endl;
    }
};

int main() {
    // Використання динамічного поліморфізму через вказівник базового класу
    unique_ptr<Student> undergraduatePtr = make_unique<Undergraduate>("Ivan", "Petrov", 1);
    unique_ptr<Student> postgraduatePtr = make_unique<Postgraduate>("Maria", "Ivanova", 2);

    // Виклик віртуальної функції через вказівник базового класу
    undergraduatePtr->displayInfo();
    undergraduatePtr->study();

    postgraduatePtr->displayInfo();
    postgraduatePtr->study();

    // Використання динамічного поліморфізму через посилання на базовий клас
    const Student& undergraduateRef = *undergraduatePtr;
    const Student& postgraduateRef = *postgraduatePtr;

    // Виклик віртуальної функції через посилання на базовий клас
    undergraduateRef.displayInfo();
    postgraduateRef.displayInfo();

    return 0;
}