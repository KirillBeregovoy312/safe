#include <iostream>
#include <thread>

using namespace std;
void square(int x) {
    cout << "\nResult: " << x * x << endl;
}

int main() {
    thread t1([](){ square(2); });
    thread t2([](){ square(3); });
    thread t3([](){ square(4); });

    t1.join();
    t2.join();
    t3.join();

    return 0;
}
