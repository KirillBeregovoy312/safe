#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <map>
#include <exception>
#include <sstream>

#include <windows.h>

using namespace std;

class Student {
public:
    // Модифікатори доступу
    // Ім'я
    string _name;
    // Прізвище
    string _surname;
    // Номер групи
    int _groupNumber;

    // Конструктор за замовчуванням
    Student() {}

    // Перевантажений конструктор
    Student(string name, string surname, int groupNumber)
            : _name(name), _surname(surname), _groupNumber(groupNumber) {}

    // Деструктор
    ~Student() {
        cout << "Деструктор викликався для студента " << _name << " " << _surname << endl;
    }

    // Геттери
    const string& getName() const { return _name; }
    const string& getSurname() const { return _surname; }
    int getGroupNumber() const { return _groupNumber; }

    // Сеттери
    void setName(const string& name) { _name = name; }
    void setSurname(const string& surname) { _surname = surname; }
    void setGroupNumber(int groupNumber) { _groupNumber = groupNumber; }

    // Конструктор копіювання
    Student(const Student& other) {
        _name = other._name;
        _surname = other._surname;
        _groupNumber = other._groupNumber;
    }

    // Конструктор переміщення
    Student(Student&& other) noexcept {
        _name = std::move(other._name);
        _surname = std::move(other._surname);
        _groupNumber = std::move(other._groupNumber);

        // Очистити дані з 'other', щоб уникнути подвійного звільнення
        other._name = "";
        other._surname = "";
        other._groupNumber = 0;
    }

    void printInfo() {
        cout << "Ім'я: " << this->_name << endl;
        cout << "Прізвище: " << this->_surname << endl;
        cout << "Номер групи: " << this->_groupNumber << endl;
    }

    // Унарний оператор +
    Student operator+() const {
        Student copy = *this;
        copy._name += " (копія)";
        return copy;
    }
    friend istream& operator>>(istream &in, Student &student) {
        cout << "Введіть ім'я: ";
        in >> student._name;

        cout << "Введіть прізвище: ";
        in >> student._surname;

        cout << "Введіть номер групи: ";
        int groupNumber;
        in >> groupNumber;

        // Перевірка валідності номера групи
        while (groupNumber <= 0) {
            cout << "Невірний номер групи. Введіть ще раз: ";
            in >> groupNumber;
        }

        student._groupNumber = groupNumber;

        return in;
    }

// Перевантаження оператора <<
    friend ostream& operator<<(ostream& out, const Student& student) {
        out << "Ім'я: " << student._name << endl;
        out << "Прізвище: " << student._surname << endl;
        out << "Номер групи: " << student._groupNumber << endl;

        return out;
    }

// Бінарний оператор +
    Student operator+(const Student& lhs) {
        Student result;
        result._name = lhs._name + " " + this->_name;
        result._surname = lhs._surname + " " + this->_surname;
        // Додавання номерів груп не має сенсу
        // result._groupNumber = lhs._groupNumber + rhs._groupNumber;

        return result;
    }
};

class Group {
public:
    // Модифікатори доступу
    // Назва групи
    string _name;
    // Список студентів
    vector<Student> _students;

    // Конструктор за замовчуванням
    Group() {}
    // Перевантажений конструктор
    Group(string name) : _name(name) {}

// Деструктор
    ~Group() {
        cout << "Деструктор викликався для групи " << _name << endl;
    }

// Геттери
    const string& getName() const { return _name; }

// Сеттери
    void setName(const string& name) { _name = name; }

// Додати студента
    void addStudent(Student&& student) {
        _students.push_back(std::move(student));
    }

// Отримати ітератор на початок списку
    vector<Student>::const_iterator begin() const { return _students.begin(); }

// Отримати ітератор на кінець списку
    vector<Student>::const_iterator end() const { return _students.end(); }
};

class University {
public:
    // Модифікатори доступу
    // Назва університету
    string _name;
    // Список груп
    vector<Group> _groups;
    // Додати студента до групи за індексом
    void addStudentToGroup(size_t groupIndex, Student&& student) {
        if (groupIndex < _groups.size()) {
            _groups[groupIndex].addStudent(std::move(student));
        } else {
            cout << "Невірний індекс групи!" << endl;
        }
    }


    // Конструктор за замовчуванням
    University() {}

    // Перевантажений конструктор
    University(string name) : _name(name) {}

    // Деструктор
    ~University() {
        cout << "Деструктор викликався для університету " << _name << endl;
        for (Group& group : _groups) {
            group.~Group();
        }
    }

    // Геттери
    const string& getName() const { return _name; }
    const vector<Group>& getGroups() const { return _groups; }

    // Сеттери
    void setName(const string& name) { _name = name; }

    // Додати групу
    void addGroup(Group&& group) {
        _groups.push_back(std::move(group));
    }

    static int _numberOfUniversities;

    explicit University(University&& u) : _name(std::move(u._name)) {
        _numberOfUniversities++;
    }

    static int getNumberOfUniversities() {
        return _numberOfUniversities;
    }
};

int University::_numberOfUniversities = 0;

void printStudentInfo(const Student& student) {
    cout << student.getName() << " " << student.getSurname() << " (" << student.getGroupNumber() << ")" << endl;
}

void loadFromFile(University& university) {
    ifstream file("file_load.txt");
    if (file.is_open()) {
        string line;
        while (getline(file, line)) {
            // Видаляємо пробільні символи на початку та в кінці рядка
            //line = regex_replace(line, regex("^\\s+|\\s+$"), "");

            // Розділення рядка на окремі частини
            istringstream iss(line);
            string name, surname;
            int groupNumber;

            // Перевірка на успішне зчитування даних
            if (!(iss >> name >> surname >> groupNumber)) {
                cout << "Невірний формат рядка: " << line << endl;
                continue; // Перейти до наступного рядка
            }

            // Створення об'єкта студента з отриманими даними
            Student student(name, surname, groupNumber);
            // Додавання студента до першої групи університету
            university.addStudentToGroup(0, std::move(student));
        }
        file.close();
    } else {
        cout << "Не вдалося відкрити файл file_load.txt" << endl;
    }
}

// Збереження даних у файл
void saveToFile(const University& university) {
    ofstream file("file_save.txt");
    if (file.is_open()) {
        for (const Group& group : university.getGroups()) {
            file << "Група: " << group.getName() << endl;
            for (const Student& student : group._students) {
                file << student.getName() << " " << student.getSurname() << " " << student.getGroupNumber() << endl;
            }
        }
        file.close();
    } else {
        cout << "Не вдалося відкрити файл university.data" << endl;
    }
}

// Обробка винятків
void handleException(const exception& ex) {
    cout << "Виникла помилка: " << ex.what() << endl;
}
void userMenu(const University& university) {
    int choice;
    do {
        cout << "\n\nМЕНЮ КОРИСТУВАЧА\n\n";
        cout << "1. Переглянути список груп\n";
        cout << "2. Переглянути список студентів у групі\n";
        cout << "3. Знайти студента за прізвищем\n";
        cout << "0. Повернутися до головного меню\n";
        cout << "Ваш вибір: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                // Виведення списку груп
                if (university.getGroups().empty()) {
                    cout << "Список груп порожній!" << endl;
                } else {
                    cout << "Список груп:\n";
                    for (const Group& group : university.getGroups()) {
                        cout << "- " << group.getName() << endl;
                    }
                }
                break;
            }
            case 2: {
                try {
                    // Вибір групи
                    cout << "Список груп:\n";
                    for (int i = 0; i < university.getGroups().size(); i++) {
                        cout << i + 1 << ". " << university.getGroups()[i].getName() << endl;
                    }

                    int groupIndex;
                    cout << "Введіть номер групи: ";
                    cin >> groupIndex;

                    if (groupIndex > 0 && groupIndex <= university.getGroups().size()) {
                        const Group& group = university.getGroups()[groupIndex - 1];

                        // Виведення списку студентів
                        if (group._students.empty()) {
                            cout << "Список студентів у групі " << group.getName() << " порожній!" << endl;
                        } else {
                            cout << "Список студентів у групі " << group.getName() << ":\n";
                            for (auto it = group._students.begin(); it != group._students.end(); ++it) {
                                cout << "- " << it->getName() << " " << it->getSurname() << endl;
                            }
                        }
                    } else {
                        cout << "Невірний номер групи!" << endl;
                    }
                } catch (const exception& ex) {
                    handleException(ex);
                }
                break;
            }
            case 3: {
                // ваш код
                break;
            }
            case 0:
                cout << "Повернення до головного меню..." << endl;
                break;
            default:
                cout << "Невірний вибір! Спробуйте ще раз." << endl;
        }
    } while (choice != 0);
}

// Меню адміністратора
void adminMenu(University& university) {
    int choice;
    do {
        cout << "\n\nМЕНЮ АДМІНІСТРАТОРА\n\n";
        cout << "1. Додати групу\n";
        cout << "2. Додати студента до групи\n";
        cout << "3. Видалити студента з групи\n";
        cout << "4. Зберегти дані до файлу\n";
        cout << "5. Завантажити дані з файлу\n";
        cout << "0. Повернутися до головного меню\n";
        cout << "Ваш вибір: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                try {
                    Group group;
                    cout << "Введіть назву групи: ";
                    cin >> (int &) group.getName();

                    university.addGroup(move(group));
                    cout << "Група успішно додана!" << endl;
                } catch (const exception& ex) {
                    handleException(ex);
                }
                break;
            }
            case 2: {
                try {
                    // Вибір групи
                    cout << "Список груп:\n";
                    for (int i = 0; i < university.getGroups().size(); i++) {
                        cout << i + 1 << ". " << university.getGroups()[i].getName() << endl;
                    }

                    int groupIndex;
                    cout << "Введіть номер групи: ";
                    cin >> groupIndex;

                    if (groupIndex > 0 && groupIndex <= university.getGroups().size()) {
                        Group group = university.getGroups()[groupIndex - 1];

                        // Додавання студента
                        Student student;
                        cin >> student;

                        group.addStudent(move(student));
                        cout << "Студент успішно доданий до групи!" << endl;
                    } else {
                        cout << "Невірний номер групи!" << endl;
                    }
                } catch (const exception& ex) {
                    handleException(ex);
                }
                break;
            }
            case 3: {
                try {
                    // Вибір групи
                    cout << "Список груп:\n";
                    for (size_t i = 0; i < university.getGroups().size(); i++) {
                        cout << i + 1 << ". " << university.getGroups()[i].getName() << endl;
                    }

                    size_t groupIndex;
                    cout << "Введіть номер групи: ";
                    cin >> groupIndex;

                    if (groupIndex > 0 && groupIndex <= university.getGroups().size()) {
                        auto& group = university.getGroups()[groupIndex - 1];

                        // Вибір студента
                        cout << "Список студентів:\n";
                        for (size_t i = 0; i < group._students.size(); i++) {
                            cout << i + 1 << ". " << group._students[i].getName() << " " << group._students[i].getSurname() << endl;
                        }

                        size_t studentIndex;
                        cout << "Введіть номер студента: ";
                        cin >> studentIndex;

                        if (studentIndex > 0 && studentIndex <= group._students.size()) {
                            cout << "Індекс студента: " << studentIndex << ", Розмір вектора студентів: " << group._students.size() << endl; // Вивід індексу та розміру вектора перед видаленням

                            size_t correctedStudentIndex = studentIndex - 1;
                            cout << "Індекс студента для видалення: " << correctedStudentIndex << endl; // Вивід індексу перед видаленням
                            auto it = group._students.begin() + correctedStudentIndex;
                            //1group._students.erase(it);
                            cout << "Студент успішно видалений з групи!" << endl;
                        } else {
                            cout << "Невірний номер студента!" << endl;
                        }
                    } else {
                        cout << "Невірний номер групи!" << endl;
                    }
                } catch (const exception& ex) {
                    handleException(ex);
                }
                break;
            }
            case 4:
                saveToFile(university);
                cout << "Дані успішно збережені до файлу!" << endl;
                break;
            case 5:
                loadFromFile(university);
                cout << "Дані успішно завантажені з файлу!" << endl;
                break;
            case 0:
                cout << "Повернення до головного меню..." << endl;
                break;
            default:
                cout << "Невірний вибір! Спробуйте ще раз." << endl;
        }
    } while (choice != 0);
}


// Консольне меню
void showMenu(University& university) {
    int choice;
    do {
        cout << "\n\nМЕНЮ\n\n";
        cout << "1. Авторизація адміністратора\n";
        cout << "2. Вхід як користувач\n";
        cout << "0. Вихід\n";
        cout << "Ваш вибір: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                string password;
                cout << "Введіть пароль: ";
                cin >> password;

                if (password == "admin") {
                    adminMenu(university);
                } else {
                    cout << "Неправильний пароль!" << endl;
                }
                break;
            }
            case 2:
                userMenu(university);
                break;
            case 0:
                cout << "Вихід з програми..." << endl;
                break;
            default:
                cout << "Невірний вибір! Спробуйте ще раз." << endl;
        }
    } while (choice != 0);
}





int main() {
    SetConsoleOutputCP(CP_UTF8);

    University university("Чернівецький національний університет ім. Юрія Федьковича");

    // Завантаження даних з файлу
    loadFromFile(university);

    // Відображення головного меню
    showMenu(university);

    return 0;
}